-- Creating the EMP_TEST table
CREATE TABLE EMP_TEST (
                          EMP_ID NUMBER PRIMARY KEY,
                          EMP_NAME VARCHAR2(100),
                          JOB_TITLE VARCHAR2(50),
                          SALARY NUMBER
);

-- Inserting sample records
INSERT INTO EMP_TEST VALUES (1, 'John Doe', 'Manager', 50000);
INSERT INTO EMP_TEST VALUES (2, 'Jane Smith', 'Developer', 40000);
INSERT INTO EMP_TEST VALUES (3, 'Bob Johnson', 'Analyst', 35000);

-- PL/SQL block for bonus calculation
DECLARE
    -- Declare variables
    v_emp_id EMP_TEST.EMP_ID%TYPE;
v_emp_name EMP_TEST.EMP_NAME%TYPE;
v_job_title EMP_TEST.JOB_TITLE%TYPE;
v_salary EMP_TEST.SALARY%TYPE;
v_bonus NUMBER;

    -- Declare cursor
CURSOR emp_cursor IS
SELECT EMP_ID, EMP_NAME, JOB_TITLE, SALARY
FROM EMP_TEST;

BEGIN
    -- Open cursor and loop through records
    OPEN emp_cursor;

LOOP
        -- Fetch employee data
        FETCH emp_cursor INTO v_emp_id, v_emp_name, v_job_title, v_salary;

        -- Exit loop when no more records
EXIT WHEN emp_cursor%NOTFOUND;

        -- Calculate bonus based on job title
CASE v_job_title
            WHEN 'Manager' THEN
                v_bonus := v_salary * 0.20;
WHEN 'Developer' THEN
                v_bonus := v_salary * 0.10;
ELSE
                v_bonus := v_salary * 0.05;
END CASE;

        -- Display employee details and bonus
DBMS_OUTPUT.PUT_LINE('Employee: ' || v_emp_name);
DBMS_OUTPUT.PUT_LINE('Job Title: ' || v_job_title);
DBMS_OUTPUT.PUT_LINE('Salary: $' || v_salary);
DBMS_OUTPUT.PUT_LINE('Bonus: $' || v_bonus);
DBMS_OUTPUT.PUT_LINE('------------------------');

END LOOP;

    -- Close cursor
CLOSE emp_cursor;

EXCEPTION
    -- Handle no data found
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Error: No employee data found in EMP_TEST table');

    -- Handle other exceptions
WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
END;
/