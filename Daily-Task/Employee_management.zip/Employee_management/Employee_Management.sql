CREATE TABLE EMPLOYEES (
    EMPLOYEE_ID NUMBER PRIMARY KEY,
    FIRST_NAME VARCHAR2(50),
    LAST_NAME VARCHAR2(50),
    EMAIL VARCHAR2(100),
    PHONE_NUMBER VARCHAR2(20),
    HIRE_DATE DATE,
    JOB_ID VARCHAR2(10),
    SALARY NUMBER,
    DEPARTMENT_ID NUMBER
);

DECLARE
    CURSOR high_salary_cur IS
        SELECT FIRST_NAME, LAST_NAME, SALARY
        FROM EMPLOYEES
        WHERE SALARY > 50000;

    v_fname EMPLOYEES.FIRST_NAME%TYPE;
    v_lname EMPLOYEES.LAST_NAME%TYPE;
    v_salary EMPLOYEES.SALARY%TYPE;
BEGIN
    OPEN high_salary_cur;
    LOOP
        FETCH high_salary_cur INTO v_fname, v_lname, v_salary;
        EXIT WHEN high_salary_cur%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Name: ' || v_fname || ' ' || v_lname || ' | Salary: ' || v_salary);
    END LOOP;
    CLOSE high_salary_cur;
END;
/
CREATE OR REPLACE PROCEDURE print_employees_by_dept(p_dept_id IN NUMBER) IS
BEGIN
    FOR emp_rec IN (
        SELECT FIRST_NAME, LAST_NAME
        FROM EMPLOYEES
        WHERE DEPARTMENT_ID = p_dept_id
    )
    LOOP
        DBMS_OUTPUT.PUT_LINE(emp_rec.FIRST_NAME || ' ' || emp_rec.LAST_NAME);
    END LOOP;
END;
/
CREATE OR REPLACE FUNCTION get_annual_salary(p_emp_id IN NUMBER)
RETURN NUMBER IS
    v_salary EMPLOYEES.SALARY%TYPE;
BEGIN
    SELECT SALARY INTO v_salary
    FROM EMPLOYEES
    WHERE EMPLOYEE_ID = p_emp_id;

    RETURN v_salary * 12;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END;
/

CREATE OR REPLACE TRIGGER trg_check_min_salary
BEFORE INSERT ON EMPLOYEES
FOR EACH ROW
BEGIN
    IF :NEW.SALARY < 30000 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Salary must be at least 30000.');
    END IF;
END;
/

CREATE OR REPLACE PACKAGE EMPLOYEE_UTILS AS
    PROCEDURE update_salary(p_emp_id IN NUMBER, p_new_salary IN NUMBER);
    FUNCTION count_employees(p_dept_id IN NUMBER) RETURN NUMBER;
END EMPLOYEE_UTILS;
/
CREATE OR REPLACE PACKAGE BODY EMPLOYEE_UTILS AS

    PROCEDURE update_salary(p_emp_id IN NUMBER, p_new_salary IN NUMBER) IS
    BEGIN
        UPDATE EMPLOYEES
        SET SALARY = p_new_salary
        WHERE EMPLOYEE_ID = p_emp_id;
    END;

    FUNCTION count_employees(p_dept_id IN NUMBER) RETURN NUMBER IS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count
        FROM EMPLOYEES
        WHERE DEPARTMENT_ID = p_dept_id;
        RETURN v_count;
    END;

END EMPLOYEE_UTILS;
/

BEGIN
    EMPLOYEE_UTILS.update_salary(101, 60000);
    DBMS_OUTPUT.PUT_LINE('Updated Salary.');

    DBMS_OUTPUT.PUT_LINE('Employees in Dept 10: ' || EMPLOYEE_UTILS.count_employees(10));
END;
/
